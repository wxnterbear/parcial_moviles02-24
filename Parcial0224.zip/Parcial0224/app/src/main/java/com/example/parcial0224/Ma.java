package com.example.parcial0224;



public class Ma {

    public double contadorManzana(double valor1) {

        return valor1++;
    }

    public double contadorSandia(double valor1) {

        return valor1++;
    }



}
