package com.example.parcial0224;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class segundo extends AppCompatActivity{

    Intent i = getIntent();

    private TextView name;
    private TextView lastname;
    private Button manzana;
    private Button sandia;
    private Button compra;

    @SuppressLint("SetTextI18n")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.segundo);

        name = findViewById(R.id.name);
        lastname = findViewById(R.id.ape);
        manzana = findViewById(R.id.b_manzana);
        sandia = findViewById(R.id.b_sandia);
        compra = findViewById(R.id.b_compra);


        name.setText("hola," + i.getStringExtra("name"));
        lastname.setText("hola," + i.getStringExtra("lastname"));





    }

}
