package com.example.parcial0224;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button sig;
    private EditText nombre;

    private EditText apellido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sig = findViewById(R.id.b_sigam);
        nombre = findViewById(R.id.id_nom);
        apellido = findViewById(R.id.id_ape);

        sig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String n = nombre.getText().toString().trim();
                String a = apellido.getText().toString().trim();


                if (TextUtils.isEmpty(n)){

                    Toast.makeText(MainActivity.this, "No se ha registrado ningun nombre, vuele a intentarlo", Toast.LENGTH_SHORT).show();

                }else {

                    Intent i = new Intent(MainActivity.this, segundo.class);
                    i.putExtra("name", n);
                    i.putExtra("lastname", a);
                    startActivity(i);

                }


            }



        });
    }
}

