package com.example.parcial0224;

import junit.framework.TestCase;

import org.junit.Test;

public class MaTest extends TestCase {

    @Test
    public void testContadorManzana() {


            Ma m = new Ma();
            int resultado = (int) m.contadorManzana(2);
            assertEquals(2, resultado);

    }

    @Test
    public void testContadorSandia() {

        Ma m = new Ma();
        int resultado = (int) m.contadorManzana(1);
        assertEquals(1, resultado);

    }
}